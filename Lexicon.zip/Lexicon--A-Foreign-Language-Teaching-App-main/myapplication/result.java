package com.example.myapplication;

public class result {
    public static int score=0;
}
