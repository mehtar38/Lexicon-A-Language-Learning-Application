# Lexicon--A-Foreign-Language-Teaching-App
An app made using Android Studio which was inspired by Duolingo and helps Hindi speakers learn English.
